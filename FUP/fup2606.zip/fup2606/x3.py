i = input('Qual a sua data de nascimento? ')
a = i.split('/')

if a[-2] == '01':
    a[1:2] = ['Janeiro']

if a[-2] == '02':
    a[1:2] = ['Fevereiro']

if a[-2] == '03':
    a[1:2] = ['Março']

if a[-2] == '04':
    a[1:2] = ['Abril']

if a[-2] == '05':
    a[1:2] = ['Maio']

if a[-2] == '06':
    a[1:2] = ['Junho']

if a[-2] == '07':
    a[1:2] = ['Julho']

if a[-2] == '08':
    a[1:2] = ['Agosto']

if a[-2] == '09':
    a[1:2] = ['Setembro']

if a[-2] == '10':
    a[1:2] = ['Outubro']

if a[-2] == '11':
    a[1:2] = ['Novembro']

if a[-2] == '12':
    a[1:2] = ['Dezembro']

print(f'Você nasceu no dia {a[0]} de {a[1]} de {a[2]}')