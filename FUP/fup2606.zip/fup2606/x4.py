curso = 'Programação em Python'

print(len(curso.replace(" ", '')))
print('prog' in curso)
print(curso.count('i'))
print(curso.count('I'))
print(curso.count('o'))
print(curso.count('O'))
print(curso.find('o'))
print(curso.rfind('o'))
