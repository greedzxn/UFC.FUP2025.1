string1 = input('Digite alguma coisa ')
string2 = input('Digite alguma coisa')

lista1 = list(string1)
lista2 = list(string2)

print(lista1)
print(lista2)
print((len(lista1)))
print((len(lista2)))