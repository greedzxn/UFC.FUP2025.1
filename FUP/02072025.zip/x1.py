while True:
    a = input('Digite uma frase: ')
    
    print(f'O espaço em branco aparece {a.count(' ')} vezes')
    print(f'A letra "o" aparece {a.count('o')} vezes')
    print(f'A letra "a" aparece {a.count('a')} vezes')
    print(f'A letra "e" aparece {a.count('e')} vezes')
    print(f'A letra "i" aparece {a.count('i')} vezes')
    print(f'A letra "u" aparece {a.count('u')} vezes')


