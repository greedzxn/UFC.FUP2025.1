nome = input('Escreva seu nome ').upper()
nome = list(nome)
nome = nome[::-1]

print(f'Seu nome ao contrário é {nome}')
